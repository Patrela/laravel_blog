<footer class="footer margen-interno">
    <nav class="pie">
        <a href="https://www.master-union.com" target="_blank">Portfolio &copy; Patricia Varela</a>
    </nav>
</footer>
