<div class="text-primary">
    <h2 class="fw-bold fs-1"></h2>
</div>

<div class="article-container">

    <article class="article">
        <img src="" class="img">
        <div class="card-body">
            <a href="#">
                <h2 class="title"></h2>
            </a>
            <p class="introduction"></p>
        </div>
    </article>

</div>

<div class="links-paginate">
    
</div>
