<div class="text-primary">
    <h2>TODAS LAS CATEGORIAS</h2>
</div>

<div class="article-container">
    <!-- Listar categorías -->
    <article class="article category">
        <img src="#" class="img">
        <div class="card-body">
            <a href="#">
                <h2 class="title category fs-4"></h2>
            </a>
        </div>
    </article>
</div>

<div class="links-paginate">    
</div>
