<footer class="footer margen-interno">
    <nav class="pie">
        <a href="https://edutin.com" target="_blank">Desarrollado por &copy; Edutin Academy</a>
    </nav>
</footer>