<div class="card">
    <div class="card-body">
        <p>Nombre completo:</p>
        <p class="form-control"></p>

        <h5>Roles</h5>
        <form action="#" method="POST">

            <div>
                <label>
                    <input type="radio" name="role" id="role" value="" class="mr-1 mb-3">

                </label>
            </div>
            
            <input type="submit" value="Establecer rol" class="btn btn-primary">
        </form>
    </div>
</div>


