<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/manage_post/category.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', 'blog'); ?>
<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    

    <div class="article-container">
        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="article">
                <img src="<?php echo e(asset('storage/' . $article->image)); ?>" class="img">
                <div class="card-body">
                    <a href="<?php echo e(route('articles.show', $article)); ?>"> 
                        <h2 class="title"><?php echo e(Str::limit($article->title, 60, '...')); ?></h2>
                    </a>
                    <p class="introduction"><?php echo e(Str::limit($article->introduction, 100, '...')); ?></p>
                </div>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <div class="links-paginate">
        <?php echo e($articles->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Server\php\laravel\blog\resources\views/home/index.blade.php ENDPATH**/ ?>