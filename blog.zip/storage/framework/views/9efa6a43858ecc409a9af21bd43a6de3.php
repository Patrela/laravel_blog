<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('css/login/login.css')); ?>" rel="stylesheet" >
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>

    <form method="POST" class="form" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
        <h2>Login</h2>
        <div class="content-login">
            <div class="input-content">
                <input type="text" name="email" placeholder="email"
                    value="<?php echo e(old('email')); ?>" autofocus>

                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger">
                            <span> * <?php echo e($message); ?></span>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

            <div class="input-content">
                <input type="password" name="password" placeholder="password" value="">

                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger">
                    <span> * <?php echo e($message); ?></span>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


            </div>
        </div>

        <a href="<?php echo e(route('password.request')); ?>" class="password-reset">Forgot your password?</a>

        <input type="submit" value="login" class="button">
    </form>

    <p>¿Don't have an account? <a href="<?php echo e(route('register')); ?>" class="link">Register</a></p>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Server\php\laravel\blog\resources\views/auth/login.blade.php ENDPATH**/ ?>