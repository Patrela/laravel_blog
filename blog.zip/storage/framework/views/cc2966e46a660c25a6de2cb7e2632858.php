<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('css/login/reset.css')); ?>" rel="stylesheet" >
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Correo de Recuperación'); ?>

<?php $__env->startSection('content'); ?>
    <form method="POST" class="form" action="<?php echo e(route('password.email')); ?>">
        <?php echo csrf_field(); ?>
        <h2 class="reset-title">Restablecer tu contraseña</h2>
        <p class="alert-send">Escribe tu correo electrónico y te enviaremos las
            instrucciones para restablecer tu contraseña</p>

        <div class="content-reset">
            <input class="form-control" id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" required>

            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger">
                *<?php echo e($message); ?>

            </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <input type="submit" value="Enviar" class="button">
        <?php if(session('status')): ?>
            <div class="reminder">
                    <p class="alert-send"><?php echo e(session('status')); ?></p>
            </div>
        <?php endif; ?>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Server\php\laravel\blog\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>