<header class="header">
    <div class="menu">

        <div class="logo">
            <!--Logo-->
            <a href="<?php echo e(route('home.index')); ?>"><img src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo"></a>
        </div>
        <nav class="nav">
        <?php if(auth()->guard()->guest()): ?>
            <ul class="d-flex">
                <li class="me-2"><a href="<?php echo e(route('login')); ?>" class="login">Login</a></li>
                <li><a href="<?php echo e(route('register')); ?>" class="create">Register</a></li>
            </ul>
        <?php else: ?>
            <div class="dropdown">
                <a class="btn dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                data-bs-toggle="dropdown" aria-expanded="false">

                    <img src="<?php echo e(Auth::user()->profile->photo ?
                            asset('storage/' . Auth::user()->profile->photo )
                            : asset('img/user-default.png')); ?>"
                            alt="Profile" class="img-profile">

                    <span class="name-user"><?php echo e(Auth::user()->full_name); ?></span>
                </a>

                <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                    <li><a class="dropdown-item"
                            href="<?php echo e(route('profiles.edit', Auth::user()->profile)); ?>">Profile</a></li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.index')): ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('admin.index')); ?>">Management</a></li>
                    <?php endif; ?>

                    <li>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">Exit</a>
                    </li>
                </ul>
            </div>
        <?php endif; ?>

        </nav>
    </div>

</header>
<?php /**PATH C:\Server\php\laravel\blog\resources\views/layouts/menu.blade.php ENDPATH**/ ?>