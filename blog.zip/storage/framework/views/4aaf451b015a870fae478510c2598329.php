<?php $__env->startSection('title', 'Comments'); ?>

<?php $__env->startSection('content_header'); ?>
<h2>Comments</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('success_message')): ?>
    <div class="alert alert-info">
        <?php echo e(session('success_message')); ?>

    </div>
    <?php endif; ?>
    <div class="card">
        <div class="card-body">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Article</th>
                        <th>Rate☆</th>
                        <th>Comment</th>
                        <th>User</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($comment->title); ?></td>
                        <td><?php echo e($comment->value); ?></td>
                        <td><?php echo e($comment->description); ?></td>
                        <td><?php echo e($comment->full_name); ?></td>

                        <td width="10px">
                            <form action="<?php echo e(route('comments.destroy', $comment->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <input type="submit" value="Delete" class="btn btn-danger btn-sm">
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Server\php\laravel\blog\resources\views/admin/comments/index.blade.php ENDPATH**/ ?>