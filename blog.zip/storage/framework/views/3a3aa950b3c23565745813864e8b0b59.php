<div class="category-container">
    <ul>
        <li class="nav-item <?php echo e(request()->routeIs('home.index')? 'active' : ''); ?>"><a href="<?php echo e(route('home.index')); ?>">Artículos</a></li>
        <?php $__currentLoopData = $navbar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item <?php echo Request::path() == 'categories/detail/' . $category->slug? 'active' : ''; ?>">
                <a href="<?php echo e(route('categories.articlesByCategory', $category)); ?>"> <?php echo e($category->name); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <li class="nav-item <?php echo e(request()->routeIs('home.all')? 'active' : ''); ?>">
            <a href="<?php echo e(route('home.all')); ?>">Categorías</a>
        </li>

    </ul>
</div>
<?php /**PATH C:\Server\php\laravel\blog\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>