<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('css/user/profile.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/user/profile_article.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title','Editar Perfil'); ?>
<?php $__env->startSection('content'); ?>
    <div class="btn-article">
        <a href="<?php echo e(route('home.index')); ?>" class="btn-new-article">⬅</a>
    </div>

    <div class="main-content">
        <div class="title-page-admin">
            <h2>Editar Perfil</h2>
        </div>
        <form method="POST" action="<?php echo e(route('profiles.update', $profile)); ?>" enctype="multipart/form-data" class="form-article">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="content-create-article">

                <div class="input-content">
                    <label for="full_name">Nombre completo:</label>
                    <input type="text" name="full_name" placeholder="Escribe tu nombre completo"
                        value="<?php echo e($profile->user->full_name); ?>" autofocus>

                    <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger">
                            <span>* <?php echo e($message); ?></span>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <div class="input-content">
                    <label for="email">Correo eléctronico</label>
                    <input type="text" name="email" placeholder="Correo eléctronico" value="<?php echo e($profile->user->email); ?>"
                        autofocus>

                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger">
                            <span>* <?php echo e($message); ?></span>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <div class="input-content">
                    <label for="profession">Ocupación:</label>
                    <input type="text" name="profession" placeholder="Escribe ocupación o profesión"
                        value="<?php echo e($profile->profession); ?>" autofocus>

                    <?php $__errorArgs = ['profession'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger">
                            <span>* <?php echo e($message); ?></span>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <div class="input-content">
                    <label for="about">Sobre ti:</label>
                    <input type="text" name="about" placeholder="Escribe lo que quieres compartir de ti"
                        value="<?php echo e($profile->about); ?>" autofocus>

                    <?php $__errorArgs = ['about'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger">
                            <span>* <?php echo e($message); ?></span>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <h2>Redes</h2>
                <div class="input-content">
                    <label for="twitter">twitter X:</label>
                    <input type="text" name="twitter" placeholder="Cuenta de twitter X"
                        value="<?php echo e($profile->twitter); ?>" autofocus>

                    <?php $__errorArgs = ['twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger">
                            <span>* <?php echo e($message); ?></span>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
                <div class="input-content">
                    <label for="linkedin">linkedin:</label>
                    <input type="text" name="linkedin" placeholder="Cuenta de linkedin"
                        value="<?php echo e($profile->linkedin); ?>" autofocus>

                    <?php $__errorArgs = ['linkedin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger">
                            <span>* <?php echo e($message); ?></span>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <div class="input-content">
                    <label for="facebook">facebook:</label>
                    <input type="text" name="facebook" placeholder="Cuenta de facebook"
                        value="<?php echo e($profile->facebook); ?>" autofocus>

                    <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger">
                            <span>* <?php echo e($message); ?></span>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
                <h2>Foto de Perfil</h2>
                <div class="input-content">
                    
                    <input type="file" id="photo" accept="image/*" name="photo" class="form-input-file">
                    <?php if($profile->photo): ?>
                        <label>Foto actual</label>
                        <div class="img-article">
                            <img src="<?php echo e(asset('storage/' . $profile->photo)); ?>" class="img">
                        </div>

                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger">
                                <span>* <?php echo e($message); ?></span>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php endif; ?>
                </div>

                <input type="submit" value="Editar perfil" class="button">
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Server\php\laravel\blog\resources\views/subscriber/profiles/edit.blade.php ENDPATH**/ ?>