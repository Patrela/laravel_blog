<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/manage_post/categories/article_category.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', 'blog'); ?>
<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="text-primary">
        <h2>TODAS LAS CATEGORIAS</h2>
    </div>

    <div class="article-container">
        <!-- Listar categorías -->
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="article category">
                <img src="<?php echo e(asset('storage/' . $category->image )); ?>" class="img">
                <div class="card-body">
                    <a href="<?php echo e(route('categories.articlesByCategory', $category)); ?>">
                        <h2 class="title category fs-4"><?php echo e($category->name); ?> </h2>
                    </a>
                </div>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

    <div class="links-paginate">
        <?php echo e($categories->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Server\php\laravel\blog\resources\views/home/all-categories.blade.php ENDPATH**/ ?>