<?php $__env->startSection('title', 'Management'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Management</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <p>Welcome <?php echo e(Auth::user()->full_name); ?>. <b>Management for Roles - Articles - Categories - Comments.</b> </p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log("Administration with Laravel-AdminLTE"); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Server\php\laravel\blog\resources\views/admin/index.blade.php ENDPATH**/ ?>