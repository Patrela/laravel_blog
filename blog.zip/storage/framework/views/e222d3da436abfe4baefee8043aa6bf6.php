<?php $__env->startSection('title', 'Panel de administración'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Establecer Roles</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <p>Nombre completo:</p>
            <p class="form-control"><?php echo e($user->full_name); ?></p>

            <h5>Roles</h5>
            <form action="<?php echo e(route('users.update', $user)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <label>
                            <input type="radio" name="role" id="role" value="<?php echo e($role->id); ?>" <?php echo e($role->id == $user->roles->contains($role->id) ? 'checked' : ''); ?>

                             class="mr-1 mb-3"><?php echo e($role->name); ?>

                        </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <input type="submit" value="Establecer rol" class="btn btn-primary">
            </form>
        </div>
    </div>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Server\php\laravel\blog\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>