<div class="form-content">
    <form method="POST" action="<?php echo e(route('comments.store')); ?>" class="form-general comments">
        <?php echo csrf_field(); ?>
        <div class="form-group fs-5">
            <label for="start-label-title">Rate this article:</label>
        </div>
        <div class="form-group rating">
            <input id="star5" name="value" type="radio" value="5" class="radio-btn hide" checked />
            <label for="star5">☆</label>
            <input id="star4" name="value" type="radio" value="4" class="radio-btn hide" />
            <label for="star4">☆</label>
            <input id="star3" name="value" type="radio" value="3" class="radio-btn hide" />
            <label for="star3">☆</label>
            <input id="star2" name="value" type="radio" value="2" class="radio-btn hide" />
            <label for="star2">☆</label>
            <input id="star1" name="value" type="radio" value="1" class="radio-btn hide" />
            <label for="star1">☆</label>
            <div class="clear"></div>
            <?php $__errorArgs = ['value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger">
                    <span>* <?php echo e($message); ?></span>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>

        <div class="form-group">
            <textarea name='description' id="description"><?php echo e(old('description')); ?></textarea>
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger">
                    <span>* <?php echo e($message); ?></span>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


        </div>

        <div class="form-group"><input type="hidden" name="article_id" value="<?php echo e($article->id); ?>"></div>

        <input type="submit" value="Send" class="btn-submit btn-comment mt-2">

    </form>
</div>
<?php /**PATH C:\Server\php\laravel\blog\resources\views/subscriber/comments/create.blade.php ENDPATH**/ ?>