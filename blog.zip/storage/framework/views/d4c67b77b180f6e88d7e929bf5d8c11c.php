<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('css/login/login.css')); ?>" rel="stylesheet" >
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Crear Cuenta'); ?>

<?php $__env->startSection('content'); ?>
    <form method="POST" class="form" action="<?php echo e(route('register')); ?>" novalidate>
        <?php echo csrf_field(); ?>
        <h2>Crear cuenta</h2>
        <div class="content-login">
            <div class="input-content">
                <input type="text" name="name" placeholder="Nombre"
                    value="<?php echo e(old('name')); ?>"
                    autofocus>

                    <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger">
                            <span> * <?php echo e($message); ?></span>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="input-content">
                <input type="text" name="full_name" placeholder="Nombre completo"
                    value="<?php echo e(old('full_name')); ?>"
                    autofocus>

                    <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger">
                            <span> * <?php echo e($message); ?></span>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="input-content">
                <input type="text" name="email" placeholder="Correo eléctronico"
                    value="<?php echo e(old('email')); ?>"
                    autofocus>

                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger">
                            <span> * <?php echo e($message); ?></span>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="input-content">
                <input type="password" name="password" placeholder="Contraseña">

                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger">
                    <span> * <?php echo e($message); ?></span>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

            <div class="input-content">
                <input type="password" name="password_confirmation" placeholder="Confirmar contraseña">
            </div>
        </div>

        <input type="submit" value="Registrarse" class="button">
        <p>¿Ya tienes una cuenta? <a href="<?php echo e(route('login')); ?>" class="link">Iniciar sesión</a></p>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Server\php\laravel\blog\resources\views/auth/register.blade.php ENDPATH**/ ?>