<footer class="footer margen-interno">
    <nav class="pie">
        <a href="https://www.master-union.com" target="_blank">Portfolio &copy; Patricia Varela</a>
    </nav>
</footer>
<?php /**PATH C:\Server\php\laravel\blog\resources\views/layouts/footer.blade.php ENDPATH**/ ?>