<footer class="footer margen-interno">
    <nav class="pie">
        <a href="https://edutin.com" target="_blank">Desarrollado por &copy; Edutin Academy</a>
    </nav>
</footer><?php /**PATH C:\Server\php\laravel\blog\resources\views/layouts/footer.blade.php ENDPATH**/ ?>