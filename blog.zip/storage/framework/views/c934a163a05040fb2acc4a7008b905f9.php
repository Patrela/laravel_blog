<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('css/login/reset.css')); ?>" rel="stylesheet" >
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Reiniciar Clave'); ?>

<?php $__env->startSection('content'); ?>
    <form method="POST" class="form" action="<?php echo e(route('password.update')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="token" value="<?php echo e($token); ?>">

        <h2 class="reset-title">Crear contraseña</h2>

        <div class="content-reset">
            <input class="form-email" id="email" type="email" name="email" placeholder="Ingrese el correo electrónico" value="<?php echo e($email?? old('email')); ?>" required>

            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger">
                * <?php echo e($message); ?>

            </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="content-reset">
            <input class="form-password" id="password" type="password" name="password" placeholder="Ingrese la nueva contraseña" required>

            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger">
                * <?php echo e($message); ?>

            </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="content-reset">
            <input class="form-password-confirm" id="password-confirm" type="password" name="password_confirmation"  placeholder="Confirme la contraseña" required>
        </div>

        <input type="submit" value="Enviar" class="button send">

    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Server\php\laravel\blog\resources\views/auth/passwords/reset.blade.php ENDPATH**/ ?>