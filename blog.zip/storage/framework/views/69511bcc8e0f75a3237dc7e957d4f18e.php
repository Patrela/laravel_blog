<div class="comments-content">
    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="comments-body">
            <span class="comment-head"> <?php echo e($comment->user->full_name); ?> &nbsp; &nbsp; <?php echo e($comment->value); ?> ⭐</span>
            <p class="comment-description line"> <?php echo e($comment->description); ?></p>
            <span class="comment-date"><?php echo e(date_format($comment->created_at,"Y/m/d")); ?> </span>
    </div>
    <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="links-paginate">
        <?php echo e($comments->links()); ?>

    </div>
</div>
<?php /**PATH C:\Server\php\laravel\blog\resources\views/subscriber/comments/show.blade.php ENDPATH**/ ?>