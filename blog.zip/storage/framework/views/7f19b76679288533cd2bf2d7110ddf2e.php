<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('css/manage_post/comment.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/manage_post/article.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title','Artículo'); ?>
<?php $__env->startSection('content'); ?>


    <div class="content-post">

        <div class="post-title line">
            <h2 class="fw-bold"><?php echo e($article->title); ?></h2>
        </div>

        <div class="post-introduction line">
            <p><?php echo e($article->introduction); ?></p>
        </div>

        <div class="post-author line">
            <img src="<?php echo e($article->user->profile->photo ? asset('storage/' . $article->user->profile->photo) : asset('img/user-default.png')); ?>" class="img-author">

            <span>Autor:
                <a href="#"> <?php echo e($article->user->full_name); ?></a>
            </span>
        </div>

        <hr>

        <div class="post-image">
            <img src="<?php echo e(asset('storage/' . $article->image)); ?>" alt="imagen" class="post-image-img">
        </div>

        <div class="post-body line"><?php echo $article->body; ?></div>
        <hr>
    </div>

    <div class="text-primary">
        <h2>Comentarios</h2>
    </div>
    <?php if(Auth::check()): ?>
        <?php echo $__env->make('subscriber.comments.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <p class="alert-post">Para comentar debe iniciar sesión</p>
    <?php endif; ?>

    <?php if(session('success-error')): ?>
        <div class="text-danger text-center">
            <p class="fs-5"><?php echo e(session('success-error')); ?></p>
        </div>
    <?php endif; ?>
    <?php echo $__env->make('subscriber.comments.show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Server\php\laravel\blog\resources\views/subscriber/articles/show.blade.php ENDPATH**/ ?>